"""Run the registered component screens sequentially on the local GPU."""

import argparse
import os
import subprocess
import sys

from evaluation.common import ROOT, read_json, write_json


def ledger():
    plan = read_json(ROOT / "studies/compression/plan.json")
    rows = []
    for candidate in plan["candidates"]:
        recipe = read_json(ROOT / f"studies/compression/recipes/{candidate}.json")
        phases = {}
        for phase in ["screen", "smoke", "development", "final"]:
            path = ROOT / f"studies/compression/measurements/{candidate}/{phase}/run.json"
            if path.exists():
                result = read_json(path)
                phases[phase] = {
                    "status": result["status"],
                    "summary": result.get("summary"),
                    "error": result.get("error"),
                }
        rows.append(
            {
                "candidate": candidate,
                "family": recipe["family"],
                "changes": recipe["changes"],
                "phases": phases,
            }
        )
    write_json(ROOT / "studies/compression/coverage.json", {"candidates": rows})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase", choices=["screen", "smoke", "development", "final"], default="screen"
    )
    parser.add_argument("--candidates", nargs="*")
    args = parser.parse_args()
    plan = read_json(ROOT / "studies/compression/plan.json")
    env = dict(
        os.environ,
        OMP_NUM_THREADS="4",
        MKL_NUM_THREADS="4",
        PYTHONPATH="src:.",
        HF_HUB_OFFLINE="1",
        MUJOCO_GL="egl",
    )
    for candidate in args.candidates or plan["candidates"]:
        path = ROOT / f"studies/compression/measurements/{candidate}/{args.phase}/run.json"
        if path.exists():
            print(f"Preserving {candidate}/{args.phase}: {read_json(path)['status']}", flush=True)
            continue
        if (ROOT / "outputs/compression/STOP").exists():
            print("Stop requested at candidate boundary", flush=True)
            break
        log = ROOT / f"outputs/compression/{candidate}-{args.phase}.log"
        print(f"Starting {candidate}/{args.phase}", flush=True)
        with log.open("w") as stream:
            process = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "evaluation.compression.study",
                    "run",
                    "--recipe",
                    f"studies/compression/recipes/{candidate}.json",
                    "--phase",
                    args.phase,
                ],
                cwd=ROOT,
                env=env,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=14400,
                check=False,
            )
        print(f"Finished {candidate}/{args.phase}: exit {process.returncode}", flush=True)
        ledger()
    ledger()


if __name__ == "__main__":
    main()
