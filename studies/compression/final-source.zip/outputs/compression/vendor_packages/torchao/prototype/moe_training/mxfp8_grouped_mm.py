# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD 3-Clause license found in the
# LICENSE file in the root directory of this source tree.

import logging
from typing import Optional

import torch

from torchao.prototype.moe_training.kernels.mxfp8 import (
    _mxfp8_cuda_kernels_available as _mxfp8_cuda_kernels_available_quant,
)
from torchao.prototype.moe_training.kernels.mxfp8 import (
    mx_block_rearrange_2d_M_groups_cuda,
    mxfp8_quantize_2d_1x32_cutedsl,
    mxfp8_quantize_cuda_3d,
    triton_mx_block_rearrange_2d_K_groups,
    triton_mx_block_rearrange_per_group_3d,
)
from torchao.prototype.moe_training.utils import (
    conditional_nostrict_trace,
    pad_token_groups,
    unpad_token_groups,
)
from torchao.prototype.mx_formats.config import (
    MXFP8Dim1CastKernelChoice,
    ScaleCalculationMode,
)
from torchao.prototype.mx_formats.kernels import (
    _mxfp8_cuda_kernels_available as _mxfp8_cuda_kernels_available_mx,
)
from torchao.prototype.mx_formats.kernels import (
    _triton_kernels_available,
    triton_mxfp8_dequant_dim0,
    triton_to_mxfp8_dim0,
)
from torchao.prototype.mx_formats.mx_tensor import MXTensor, to_mx
from torchao.prototype.mx_formats.utils import _to_mxfp8_dim1_kernel_wrapper
from torchao.quantization.quantize_.common import KernelPreference

logger: logging.Logger = logging.getLogger(__name__)

# Check if SM100 kernels are available
# All SM100-dependent kernels are guarded at their definition sites
_SM100_KERNELS_AVAILABLE = (
    _mxfp8_cuda_kernels_available_quant
    and _mxfp8_cuda_kernels_available_mx
    and _triton_kernels_available
)


# Aliases for convenience/clarity
@conditional_nostrict_trace
def _to_mxfp8_then_scaled_grouped_mm(
    A: torch.Tensor,
    B_t: torch.Tensor,
    offs: Optional[torch.Tensor] = None,
    bias: Optional[torch.Tensor] = None,
    out_dtype: Optional[torch.dtype] = torch.bfloat16,
    kernel_preference: KernelPreference = KernelPreference.AUTO,
    wgrad_with_hp: bool = False,
    scale_calculation_mode: ScaleCalculationMode = ScaleCalculationMode.RCEIL,
    pad_token_groups_for_grouped_mm: bool = False,
) -> torch.Tensor:
    """
    Differentiable mxfp8 grouped gemm with dynamic mxfp8 quantization.

    Args:
        A (torch.Tensor): Input activations. May be a high-precision 2D tensor of
            shape (M * num_groups, K) in row-major memory layout, or an `MXTensor`
            carrying pre-quantized MXFP8 activations. If you already have raw
            `(qdata, scale)` tensors, wrap them first with
            `MXTensor.from_qdata_and_scales(...)`.
        B_t (bf16/float32 torch.Tensor): The second high-precision input tensor
            which must be 3D, which must be shape (G, K, N)
            and in "per group column-major memory" layout (i.e., strides of (N*K, 1, N)).
        offs (int32 torch.Tensor): The offsets to use to mark the end index of each group along the dim0 of the A tensor.
        out_dtype (torch.dtype): Output dtype for the result. Defaults to torch.bfloat16.
        kernel_preference (KernelPreference): Kernel preference (AUTO uses CUDA/Triton, EMULATED uses to_mx). Defaults to KernelPreference.AUTO.
        wgrad_with_hp (bool): Whether to compute weight gradient in high precision. Defaults to False.
        scale_calculation_mode (ScaleCalculationMode): Mode for scale calculation (RCEIL, FLOOR, etc.). Defaults to ScaleCalculationMode.RCEIL.
        pad_token_groups_for_grouped_mm (bool): Whether to pad token groups to the next multiple of 32 (requirement for MXFP8 grouped GEMM). If your tokens are already padded, set to False.

    Returns:
        out (torch.Tensor): The result of the mxfp8 scaled grouped gemm.
    """
    # block_size is always 32 for MXFP8
    block_size = 32
    _validate_grouped_mm_input_act(A, block_size)
    output = _MXFP8GroupedMM.apply(
        A,
        B_t,
        offs,
        out_dtype,
        kernel_preference,
        wgrad_with_hp,
        scale_calculation_mode,
        pad_token_groups_for_grouped_mm,
    )

    # add bias outside the autograd function so that autograd
    # handles the bias gradient automatically.
    if bias is not None:
        output = output + bias.to(output.dtype)

    return output


class _MXFP8GroupedMM(torch.autograd.Function):
    """
    Differentiable implementation of grouped GEMM with dynamic MXFP8 quantization.

    This autograd function performs grouped matrix multiplication with MXFP8 quantization
    for efficient MoE training. It supports both pre-quantized (`MXTensor`) and
    high-precision inputs, with configurable quantization and layout conversion options.
    """

    @staticmethod
    def forward(
        ctx,
        input_act: torch.Tensor,
        weight_t: torch.Tensor,
        group_end_offsets: Optional[torch.Tensor] = None,
        out_dtype: Optional[torch.dtype] = torch.bfloat16,
        kernel_preference: KernelPreference = KernelPreference.AUTO,
        wgrad_with_hp: bool = False,
        scale_calculation_mode: ScaleCalculationMode = ScaleCalculationMode.RCEIL,
        pad_token_groups_for_grouped_mm: bool = False,
    ) -> torch.Tensor:
        """
        Forward pass: Quantize inputs and perform grouped GEMM.

        Args:
            input_act: Input activations, shape (M, K) - may be MXTensor or high-precision
            weight_t: Expert weights transposed, shape (E, K, N) - always high-precision
            group_end_offsets: End index of each token group, shape (E,)
            out_dtype: Output dtype (bfloat16 or float32)
            kernel_preference: Kernel preference (AUTO uses CUDA/Triton, EMULATED uses to_mx)
            wgrad_with_hp: Compute weight gradient in high precision
            scale_calculation_mode: Mode for scale calculation (RCEIL, FLOOR, etc.)
            pad_token_groups_for_grouped_mm: Whether to pad token groups to the next multiple of 32

        Returns:
            Output tensor, shape (M, N)
        """
        # block_size is always 32 for MXFP8
        block_size = 32

        assert kernel_preference in (
            KernelPreference.AUTO,
            KernelPreference.EMULATED,
        ), "kernel_preference must be AUTO or EMULATED"

        # Validate SM100 kernels are available if not using emulated mode
        if kernel_preference != KernelPreference.EMULATED:
            assert _SM100_KERNELS_AVAILABLE, (
                "SM100 kernels not available. Please use torchao CUDA 12.8+ build on SM100/100a device(s). "
                "Otherwise, set kernel_preference=KernelPreference.EMULATED (emulated mode implements basic functionality without efficient kernels)."
            )

        # Input validation
        assert input_act.ndim == 2, "input_act must be 2D"
        assert weight_t.ndim == 3, "weight_t must be 3D"
        assert group_end_offsets is not None, (
            "group_end_offsets must be provided for 2d-3d grouped mm"
        )
        assert out_dtype in (
            torch.bfloat16,
            torch.float32,
        ), "out_dtype must be bfloat16 or float32"
        if isinstance(input_act, MXTensor):
            assert wgrad_with_hp, (
                "only `wgrad_with_hp` recipe is supported for MXTensor inputs because "
                "backward needs the high-precision activations to quantize along dim1 "
                "for weight gradients"
            )

        # Save original group_end_offsets and num_tokens before padding
        num_tokens = input_act.shape[0]
        padded_group_start_offsets = None
        padded_group_end_offsets = None

        # Conditionally pad token groups if not aligned to block_size
        if pad_token_groups_for_grouped_mm:
            padded_input_act, padded_group_start_offsets, padded_group_end_offsets = (
                pad_token_groups(
                    input_act,
                    group_end_offsets,
                    alignment_size=block_size,
                    kernel_preference=kernel_preference,
                )
            )
        else:
            # We don't assign padded_group_start_offsets here because it's only needed for the pad/unpad path
            padded_input_act = input_act
            padded_group_end_offsets = group_end_offsets

        # Perform forward computation using appropriate path
        output = _compute_fwd(
            padded_input_act,
            weight_t,
            padded_group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
            kernel_preference,
        )

        # Unpad output if padding was used
        if pad_token_groups_for_grouped_mm:
            output = unpad_token_groups(
                output,
                group_end_offsets,
                padded_group_start_offsets,
                num_tokens,
                alignment_size=block_size,
                kernel_preference=kernel_preference,
            )

        # Save tensors and config for backward
        ctx.save_for_backward(
            padded_input_act,
            weight_t,
            group_end_offsets,
            padded_group_start_offsets,
            padded_group_end_offsets,
        )
        ctx.out_dtype = out_dtype
        ctx.kernel_preference = kernel_preference
        ctx.wgrad_with_hp = wgrad_with_hp
        ctx.scale_calculation_mode = scale_calculation_mode
        ctx.pad_token_groups_for_grouped_mm = pad_token_groups_for_grouped_mm
        ctx.num_tokens = num_tokens

        assert output.shape[0] == num_tokens

        return output

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        """
        Backward pass: Compute gradients w.r.t. input activations and weights.

        Args:
            grad_output: Gradient from upstream, shape (M, N) - may be MXTensor

        Returns:
            tuple: (grad_input, grad_weight_t, None, ...) matching forward args
        """
        # Retrieve saved tensors and config
        (
            padded_input_act,
            weight_t,
            original_group_end_offsets,
            padded_group_start_offsets,
            padded_group_end_offsets,
        ) = ctx.saved_tensors

        # block_size is always 32 for MXFP8
        block_size = 32
        out_dtype = ctx.out_dtype
        kernel_preference = ctx.kernel_preference
        wgrad_with_hp = ctx.wgrad_with_hp
        scale_calculation_mode = ctx.scale_calculation_mode
        pad_token_groups_for_grouped_mm = ctx.pad_token_groups_for_grouped_mm
        num_tokens = ctx.num_tokens

        # Pad grad_output if padding was used in forward (needed for both dgrad and wgrad)
        if pad_token_groups_for_grouped_mm:
            # padded start/end offsets same as what we saved from forward.
            # will be original offsets if we aren't using pad/unpad path
            padded_grad_output, _, _ = pad_token_groups(
                grad_output,
                original_group_end_offsets,
                alignment_size=block_size,
                kernel_preference=kernel_preference,
            )
        else:
            padded_grad_output = grad_output

        # Compute gradient w.r.t. input activations
        grad_input = _compute_dgrad(
            padded_grad_output,
            weight_t,
            padded_group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
            kernel_preference,
        )

        # Compute gradient w.r.t. weights (high-precision or quantized)
        # Re-use padded grad_output and padded input activations computed previously
        grad_weight_t = _compute_wgrad(
            padded_grad_output,
            padded_input_act,
            padded_group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
            wgrad_with_hp,
            kernel_preference,
        )

        # Unpad grad_input if padding was used
        if pad_token_groups_for_grouped_mm:
            grad_input = unpad_token_groups(
                grad_input,
                original_group_end_offsets,
                padded_group_start_offsets,
                num_tokens,
                alignment_size=block_size,
                kernel_preference=kernel_preference,
            )

        return (
            grad_input,
            grad_weight_t,
            None,  # group_end_offsets
            None,  # out_dtype
            None,  # kernel_preference
            None,  # wgrad_with_hp
            None,  # scale_calculation_mode
            None,  # pad_token_groups_for_grouped_mm
        )


def _compute_fwd(
    padded_input_act: torch.Tensor,
    weight_t: torch.Tensor,
    padded_group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
    kernel_preference: KernelPreference,
) -> torch.Tensor:
    """
    Forward computation wrapper that dispatches to AUTO or EMULATED path.

    Args:
        padded_input_act: Input activations (possibly padded), shape (M, K)
        weight_t: Expert weights transposed, shape (E, K, N)
        padded_group_end_offsets: Group offsets (possibly padded)
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation
        kernel_preference: If EMULATED, use EMULATED path (native PyTorch), else use AUTO (SM100 kernels)

    Returns:
        Output tensor, shape (M, N)
    """
    if kernel_preference == KernelPreference.EMULATED:
        return _compute_fwd_emulated(
            padded_input_act,
            weight_t,
            padded_group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
        )
    else:
        return _compute_fwd_sm100(
            padded_input_act,
            weight_t,
            padded_group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
        )


def _compute_dgrad(
    grad_output: torch.Tensor,
    weight_t: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
    kernel_preference: KernelPreference,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. input activations, dispatching to AUTO or EMULATED path.

    Args:
        grad_output: Gradient output, shape (M, N)
        weight_t: Expert weights transposed, shape (E, K, N)
        group_end_offsets: Group offsets for grouped mm
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation
        kernel_preference: If EMULATED, use EMULATED path (native PyTorch), else use AUTO (SM100 kernels)

    Returns:
        grad_input, shape (M, K)
    """
    if kernel_preference == KernelPreference.EMULATED:
        return _compute_dgrad_emulated(
            grad_output,
            weight_t,
            group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
        )
    else:
        return _compute_dgrad_sm100(
            grad_output,
            weight_t,
            group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
        )


def _compute_wgrad(
    grad_output: torch.Tensor,
    input_act: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
    wgrad_with_hp: bool,
    kernel_preference: KernelPreference,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. weights, dispatching to AUTO or EMULATED path.

    Args:
        grad_output: Gradient output (MXTensor or high-precision), shape (M, N)
        input_act: Input activations (MXTensor or high-precision), shape (M, K)
        group_end_offsets: Group offsets
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation
        wgrad_with_hp: Whether to compute weight gradient in high precision
        kernel_preference: If EMULATED, use EMULATED path (native PyTorch), else use AUTO (SM100 kernels)

    Returns:
        grad_weight_t, shape (E, K, N)
    """
    if kernel_preference == KernelPreference.EMULATED:
        return _compute_wgrad_emulated(
            grad_output,
            input_act,
            group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
            wgrad_with_hp,
        )
    else:
        return _compute_wgrad_sm100(
            grad_output,
            input_act,
            group_end_offsets,
            block_size,
            out_dtype,
            scale_calculation_mode,
            wgrad_with_hp,
        )


def _extract_or_quantize_1x32_emulated(
    tensor: torch.Tensor,
    block_size: int,
    scale_calculation_mode: ScaleCalculationMode,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Extract qdata and scales from MXTensor or quantize using native PyTorch (EMULATED path).

    Args:
        tensor: Input tensor (MXTensor or high-precision)
        block_size: Block size for quantization
        scale_calculation_mode: Mode for scale calculation

    Returns:
        tuple: (quantized_data, scales)
    """
    if isinstance(tensor, MXTensor):
        return tensor.qdata, tensor.scale
    scale, qdata = to_mx(
        tensor,
        elem_dtype=torch.float8_e4m3fn,
        block_size=block_size,
        scaling_mode=scale_calculation_mode,
    )
    return qdata, scale


def _compute_fwd_sm100(
    padded_input_act: torch.Tensor,
    weight_t: torch.Tensor,
    padded_group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
) -> torch.Tensor:
    """
    Forward computation using AUTO path (SM100 kernels).

    Args:
        padded_input_act: Input activations (possibly padded), shape (M, K)
        weight_t: Expert weights transposed, shape (E, K, N)
        padded_group_end_offsets: Group offsets (possibly padded)
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation

    Returns:
        Output tensor, shape (M, N)
    """
    # Quantize input activations along dim0.
    # May be prequantized, if so extract qdata and scales.
    if isinstance(padded_input_act, MXTensor):
        input_act_e4m3, input_act_scales_blocked = (
            padded_input_act.qdata,
            padded_input_act.scale,
        )
        if not padded_input_act.is_swizzled_scales:
            # Convert scales to blocked layout for SM100 kernels
            input_act_scales_blocked = mx_block_rearrange_2d_M_groups_cuda(
                padded_input_act.scales, padded_group_end_offsets
            )
    else:
        input_act_e4m3, input_act_scales_blocked = mxfp8_quantize_2d_1x32_cutedsl(
            padded_input_act,
            scaling_mode=scale_calculation_mode.value.lower(),
            offs=padded_group_end_offsets,
        )

    # Quantize weights along dim0 (after transposing from (E, K, N) to (E, N, K))
    weight_e4m3, weight_scales = triton_to_mxfp8_dim0(
        weight_t.transpose(-2, -1), block_size, scale_calculation_mode.value.lower()
    )
    weight_scales_blocked = triton_mx_block_rearrange_per_group_3d(weight_scales)

    # Compute output using SM100 kernel
    output = torch._scaled_grouped_mm(
        input_act_e4m3,
        weight_e4m3.transpose(-2, -1),  # Transpose back to (E, K, N)
        input_act_scales_blocked,
        weight_scales_blocked,
        offs=padded_group_end_offsets,
        out_dtype=out_dtype,
    )
    return output


def _compute_fwd_emulated(
    padded_input_act: torch.Tensor,
    weight_t: torch.Tensor,
    padded_group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
) -> torch.Tensor:
    """
    Forward computation using EMULATED path (native PyTorch).

    Args:
        padded_input_act: Input activations (possibly padded), shape (M, K)
        weight_t: Expert weights transposed, shape (E, K, N)
        padded_group_end_offsets: Group offsets (possibly padded)
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation

    Returns:
        Output tensor, shape (M, N)
    """
    # Quantize input activations along dim0
    input_act_e4m3, input_act_scales = _extract_or_quantize_1x32_emulated(
        padded_input_act, block_size, scale_calculation_mode
    )

    # Quantize weights along dim0 (after transposing from (E, K, N) to (E, N, K))
    weight_e4m3, weight_scales = _extract_or_quantize_1x32_emulated(
        weight_t.transpose(-2, -1), block_size, scale_calculation_mode
    )

    # Use emulated BF16 path: dequantize and use regular grouped mm
    output = _emulated_mxfp8_scaled_grouped_mm_2d_3d(
        input_act_e4m3,
        input_act_scales,
        weight_e4m3.transpose(-2, -1),
        weight_scales.transpose(-2, -1),
        offs=padded_group_end_offsets,
        out_dtype=out_dtype,
        block_size=block_size,
    )
    return output


def _compute_dgrad_sm100(
    grad_output: torch.Tensor,
    weight_t: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. input activations using AUTO path (SM100 kernels).

    Args:
        grad_output: Gradient output, shape (M, N)
        weight_t: Expert weights transposed, shape (E, K, N)
        group_end_offsets: Group offsets for grouped mm
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation

    Returns:
        grad_input, shape (M, K)
    """
    # Quantize grad_output along dim0
    if isinstance(grad_output, MXTensor):
        grad_out_e4m3, grad_output_scales_blocked = grad_output.qdata, grad_output.scale
        if not grad_output.is_swizzled_scales:
            # Convert scales to blocked layout for SM100 kernels
            grad_output_scales_blocked = mx_block_rearrange_2d_M_groups_cuda(
                grad_output.scales, group_end_offsets
            )
    else:
        grad_out_e4m3, grad_output_scales_blocked = mxfp8_quantize_2d_1x32_cutedsl(
            grad_output,
            scaling_mode=scale_calculation_mode.value.lower(),
            offs=group_end_offsets,
        )

    # Quantize weights directly to blocked tcgen05 scales.
    # (E,N,K) with 1x32 scaling, per-expert column major layout.
    weight = weight_t.transpose(-2, -1)
    weight_e4m3, weight_scales_blocked = mxfp8_quantize_cuda_3d(
        weight._data if hasattr(weight, "_data") else weight,
        block_size,
        scale_block_dim1=block_size,
        scale_block_dim2=1,
        scaling_mode=scale_calculation_mode.value.lower(),
    )

    # Compute grad_input = grad_output @ weight
    grad_input = torch._scaled_grouped_mm(
        grad_out_e4m3,
        weight_e4m3,
        grad_output_scales_blocked,
        weight_scales_blocked,
        offs=group_end_offsets,
        out_dtype=out_dtype,
    )
    return grad_input


def _compute_dgrad_emulated(
    grad_output: torch.Tensor,
    weight_t: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. input activations using EMULATED path (native PyTorch).

    Args:
        grad_output: Gradient output, shape (M, N)
        weight_t: Expert weights transposed, shape (E, K, N)
        group_end_offsets: Group offsets for grouped mm
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation

    Returns:
        grad_input, shape (M, K)
    """
    # Quantize grad_output along dim0
    grad_output_data, grad_output_scales = _extract_or_quantize_1x32_emulated(
        grad_output, block_size, scale_calculation_mode
    )

    weight_e4m3, weight_scales = _quantize_3d_along_dim1_native(
        weight_t.transpose(-2, -1), block_size, scale_calculation_mode
    )

    M, N_out = grad_output_data.shape
    grad_output_data = grad_output_data.reshape(M, N_out // block_size, block_size)
    grad_output_scales = grad_output_scales.unsqueeze(-1)
    grad_output = (
        grad_output_data.to(torch.bfloat16) * grad_output_scales.to(torch.bfloat16)
    ).reshape(M, N_out)

    # dgrad uses the original weight orientation: (E, N, K).
    E, N, K = weight_e4m3.shape
    weight_e4m3 = weight_e4m3.reshape(E, N // block_size, block_size, K)
    weight_scales = weight_scales.unsqueeze(-2)
    weight = (
        weight_e4m3.to(torch.bfloat16) * weight_scales.to(torch.bfloat16)
    ).reshape(E, N, K)

    grad_input = torch._grouped_mm(
        grad_output,
        weight,
        offs=group_end_offsets,
        out_dtype=out_dtype,
    )
    return grad_input


def _compute_wgrad_sm100(
    grad_output: torch.Tensor,
    input_act: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
    wgrad_with_hp: bool = False,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. weights using AUTO path (SM100 kernels).

    Args:
        grad_output: Gradient output (MXTensor or high-precision), shape (M, N)
        input_act: Input activations (MXTensor or high-precision), shape (M, K)
        group_end_offsets: Group offsets
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation
        wgrad_with_hp: Whether to compute weight gradient in high precision

    Returns:
        grad_weight_t, shape (E, K, N)
    """
    # Dequantize if needed
    grad_output = _dequantize_if_mxtensor(grad_output, block_size)
    input_act = _dequantize_if_mxtensor(input_act, block_size)

    if wgrad_with_hp:
        grad_weight = torch._grouped_mm(
            grad_output.transpose(-2, -1),
            input_act,
            offs=group_end_offsets,
            out_dtype=out_dtype,
        )
        return grad_weight.transpose(-2, -1)

    # Use CUDA kernel for dim1 quant
    grad_output_t_mx = _to_mxfp8_dim1_kernel_wrapper(
        grad_output,
        block_size,
        elem_dtype=torch.float8_e4m3fn,
        hp_dtype=grad_output.dtype,
        kernel_preference=KernelPreference.AUTO,
        cast_kernel_choice=MXFP8Dim1CastKernelChoice.CUDA,
        scale_calculation_mode=scale_calculation_mode,
    )
    grad_output_t_data = grad_output_t_mx.qdata
    grad_output_t_scales = grad_output_t_mx.scale

    input_act_t_mx = _to_mxfp8_dim1_kernel_wrapper(
        input_act,
        block_size,
        elem_dtype=torch.float8_e4m3fn,
        hp_dtype=input_act.dtype,
        kernel_preference=KernelPreference.AUTO,
        cast_kernel_choice=MXFP8Dim1CastKernelChoice.CUDA,
        scale_calculation_mode=scale_calculation_mode,
    )
    input_act_t_data = input_act_t_mx.qdata
    input_act_t_scales = input_act_t_mx.scale

    # Convert scales to blocked layout for SM100 kernels
    scale_group_offsets = group_end_offsets // block_size
    grad_output_t_scales_blocked = triton_mx_block_rearrange_2d_K_groups(
        grad_output_t_scales,
        scale_group_offsets,
    )
    input_act_t_scales_blocked = triton_mx_block_rearrange_2d_K_groups(
        input_act_t_scales,
        scale_group_offsets,
    )

    # Compute grad_weight = grad_output_t @ input_act
    grad_weight = torch._scaled_grouped_mm(
        grad_output_t_data,
        input_act_t_data.transpose(-2, -1),
        grad_output_t_scales_blocked,
        input_act_t_scales_blocked,
        offs=group_end_offsets,
        out_dtype=out_dtype,
    )

    # Transpose to match weight_t shape in forward: (E, N, K) -> (E, K, N)
    return grad_weight.transpose(-2, -1)


def _compute_wgrad_emulated(
    grad_output: torch.Tensor,
    input_act: torch.Tensor,
    group_end_offsets: torch.Tensor,
    block_size: int,
    out_dtype: torch.dtype,
    scale_calculation_mode: ScaleCalculationMode,
    wgrad_with_hp: bool = False,
) -> torch.Tensor:
    """
    Compute gradient w.r.t. weights using EMULATED path (native PyTorch).

    Args:
        grad_output: Gradient output (MXTensor or high-precision), shape (M, N)
        input_act: Input activations (MXTensor or high-precision), shape (M, K)
        group_end_offsets: Group offsets
        block_size: Block size for quantization
        out_dtype: Output dtype
        scale_calculation_mode: Mode for scale calculation
        wgrad_with_hp: Whether to compute weight gradient in high precision

    Returns:
        grad_weight_t, shape (E, K, N)
    """
    # Dequantize if needed
    grad_output = _dequantize_if_mxtensor(grad_output, block_size)
    input_act = _dequantize_if_mxtensor(input_act, block_size)

    if wgrad_with_hp:
        grad_weight = torch._grouped_mm(
            grad_output.transpose(-2, -1),
            input_act,
            offs=group_end_offsets,
            out_dtype=out_dtype,
        )
        return grad_weight.transpose(-2, -1)

    # Use native PyTorch quantization
    grad_output_t_scales, grad_output_t_data = to_mx(
        grad_output.transpose(-2, -1).contiguous(),
        elem_dtype=torch.float8_e4m3fn,
        block_size=block_size,
        scaling_mode=scale_calculation_mode,
    )
    input_act_t_scales, input_act_t_data = to_mx(
        input_act.transpose(-2, -1).contiguous(),
        elem_dtype=torch.float8_e4m3fn,
        block_size=block_size,
        scaling_mode=scale_calculation_mode,
    )

    # Dequantize and run bf16 grouped mm for emulation
    grad_weight = _emulated_mxfp8_scaled_grouped_mm_2d_2d(
        grad_output_t_data,
        grad_output_t_scales,
        input_act_t_data,
        input_act_t_scales,
        offs=group_end_offsets,
        out_dtype=out_dtype,
        block_size=block_size,
    )
    # Transpose to match weight_t shape in forward: (E, N, K) -> (E, K, N)
    return grad_weight.transpose(-2, -1)


def _quantize_3d_along_dim1_native(
    x: torch.Tensor,
    block_size: int,
    scale_calculation_mode: ScaleCalculationMode,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Quantize a 3D tensor along its middle dimension using native PyTorch.
    Works on any hardware, not just SM100.

    Args:
        x: Input tensor of shape (E, D0, D1)
        block_size: Block size for quantization
        scale_calculation_mode: Mode for scale calculation

    Returns:
        tuple: (quantized_data, scales)
            - quantized_data: shape (E, D0, D1)
            - scales: shape (E, D0//block_size, D1)
    """
    # Transpose so the middle dimension becomes the final dimension, since
    # to_mx scales along the last dimension.
    scales, qdata = to_mx(
        x.transpose(-2, -1).contiguous(),
        elem_dtype=torch.float8_e4m3fn,
        block_size=block_size,
        scaling_mode=scale_calculation_mode,
    )

    # Transpose tensors and scales back so we have effectively
    # quantized input shape (E, N, K) along N
    qdata = qdata.transpose(-2, -1)
    scales = scales.transpose(-2, -1)

    return qdata, scales


def _dequantize_if_mxtensor(
    tensor: torch.Tensor,
    block_size: int,
) -> torch.Tensor:
    """
    Dequantize MXTensor if needed, otherwise return tensor unchanged.

    Args:
        tensor: Input tensor (MXTensor or high-precision)
        block_size: Block size for dequantization

    Returns:
        High-precision tensor
    """
    if isinstance(tensor, MXTensor):
        return triton_mxfp8_dequant_dim0(
            tensor.qdata,
            tensor.scale.view(torch.uint8),  # Triton can't handle e8m0 directly yet
            out_dtype=tensor.orig_dtype,
            scale_block_size=block_size,
        )
    return tensor


def _to_mxfp8_dim1_3d(
    B: torch.Tensor,
    block_size: int = 32,
    scaling_mode: ScaleCalculationMode = ScaleCalculationMode.FLOOR,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Convert a 3D tensor to MXFP8 format with (block_size, 1) scaling granularity.
    """
    E, N, K = B.shape
    B_reshaped = B.reshape(E * N, K)
    B_t_mx = _to_mxfp8_dim1_kernel_wrapper(
        B_reshaped,
        block_size,
        elem_dtype=torch.float8_e4m3fn,
        hp_dtype=B_reshaped.dtype,
        kernel_preference=KernelPreference.AUTO,  # Not used
        cast_kernel_choice=MXFP8Dim1CastKernelChoice.CUDA,
        scale_calculation_mode=scaling_mode,
    )
    B_data = B_t_mx.qdata.t()  # (K, E*N) -> (E*N, K)
    B_data = B_data.reshape(E, N, K)  # (E*N, K) -> (E, N, K)
    B_scales = B_t_mx.scale.view(torch.uint8)  # (K, E*N//block_size)
    B_scales = B_scales.reshape(
        K, E, N // block_size
    )  # (K, E*N//block_size) -> (K, E, N//block_size)
    B_scales = B_scales.permute(
        1, 0, 2
    )  # (K, E, N//block_size) -> (E, K, N//block_size)
    B_scales = B_scales.view(torch.float8_e8m0fnu)

    # TODO: Update cutlass grouped gemm to accept NT/TN/NN/TT layouts so we can avoid this conversion to column major
    B_data = B_data.transpose(-2, -1).contiguous().transpose(-2, -1)
    return B_scales, B_data


def _emulated_mxfp8_scaled_grouped_mm_2d_3d(
    A_data: torch.Tensor,
    A_scale: torch.Tensor,
    B_data: torch.Tensor,
    B_scale: torch.Tensor,
    offs: Optional[torch.Tensor] = None,
    out_dtype: Optional[torch.dtype] = torch.bfloat16,
    block_size: int = 32,
) -> torch.Tensor:
    assert A_data.ndim == 2, f"A must be 2D, got {A_data.ndim}"
    assert B_data.ndim == 3, f"B must be 3D, got {B_data.ndim}"
    assert A_scale.shape[0] == A_data.shape[0], (
        f"A_scale must have same M dim as A_data, got A={A_data.shape} and A_scale={A_scale.shape}"
    )
    assert A_scale.shape[1] == A_data.shape[1] // block_size, (
        f"A_scale dim1 should be size K//block_size, got A={A_data.shape} and A_scale={A_scale.shape}"
    )
    assert B_scale.shape[0] == B_data.shape[0], (
        f"B_scale must have same E dim as B_data, got B={B_data.shape} and B_scale={B_scale.shape}"
    )

    E, K, N = B_data.shape
    if (
        B_scale.shape[0] == E
        and B_scale.shape[1] == K // block_size
        and B_scale.shape[2] == N
    ):
        B_scale_for_dequant = B_scale.unsqueeze(-2)  # (E, K//32, N) -> (E, K//32, 1, N)
    else:
        raise AssertionError(
            "B_scale must match (E, N, K//block_size), "
            f"got B={B_data.shape} and B_scale={B_scale.shape}"
        )

    # Dequantize input
    # A_data shape: (M, K)
    # A_scale shape: (M, K//block_size)
    A_orig_shape = A_data.shape

    # Reshape to be able to do per-scaling group multiplication
    # A_data shape: (M, K//block_size, block_size)
    # A_scale shape: (M, K//block_size, 1)
    A_data = A_data.reshape(
        *A_data.shape[:-1], A_data.shape[-1] // block_size, block_size
    )
    A_scale = A_scale.unsqueeze(-1)

    # Rescale and cast to bfloat16
    A = A_data.to(torch.bfloat16) * A_scale.to(torch.bfloat16)

    # Reshape back to original shape
    # A shape: (M, K)
    A = A.reshape(A_orig_shape)

    # Dequantize transposed weights directly. B_t_data already has grouped-GEMM
    # layout (E, K, N) and B_t_scale stores one scale per 32 values along K.
    E, K, N = B_data.shape
    B_data = B_data.reshape(E, K // block_size, block_size, N)
    B = (B_data.to(torch.bfloat16) * B_scale_for_dequant.to(torch.bfloat16)).reshape(
        E, K, N
    )

    # Perform bf16 grouped GEMM.
    out = torch._grouped_mm(A, B, offs=offs, out_dtype=out_dtype)
    return out


def _emulated_mxfp8_scaled_grouped_mm_2d_2d(
    A_data: torch.Tensor,  # (M, K)
    A_scale: torch.Tensor,  # (M, K//block_size)
    B_data: torch.Tensor,  # (N, K)
    B_scale: torch.Tensor,  # (N, K//block_size)
    offs: torch.Tensor,
    out_dtype: Optional[torch.dtype] = torch.bfloat16,
    block_size: int = 32,
) -> torch.Tensor:
    assert A_data.ndim == 2, "A must be 2D"
    assert B_data.ndim == 2, "B must be 2D"

    M, K = A_data.shape
    N, _ = B_data.shape

    # Dequantize A: (M, K) with scales (M, K//block_size)
    A_reshaped = A_data.reshape(M, K // block_size, block_size)
    A_dequant = (
        A_reshaped.to(torch.bfloat16) * A_scale.unsqueeze(-1).to(torch.bfloat16)
    ).reshape(M, K)

    # Dequantize B: (N, K) with scales (N, K//block_size)
    B_reshaped = B_data.reshape(N, K // block_size, block_size)
    B_dequant = (
        B_reshaped.to(torch.bfloat16) * B_scale.unsqueeze(-1).to(torch.bfloat16)
    ).reshape(N, K)

    # Transpose B from (N, K) to (K, N) for matmul: A (M, K) @ B^T (K, N) = (M, N)
    out = torch._grouped_mm(
        A_dequant, B_dequant.transpose(-2, -1), offs=offs, out_dtype=out_dtype
    )
    return out


def round_up(x, y):
    return ((x + y - 1) // y) * y


def _validate_grouped_mm_input_act(
    input_act: torch.Tensor,
    block_size: int,
) -> None:
    if not isinstance(input_act, MXTensor):
        return

    assert input_act.elem_dtype == torch.float8_e4m3fn, (
        f"Expected MXTensor with elem_dtype float8_e4m3fn, but got {input_act.elem_dtype}"
    )
    assert input_act.block_size == block_size, (
        f"Expected MXTensor block_size={block_size}, but got {input_act.block_size}"
    )
    assert not input_act.is_swizzled_scales, (
        "MXTensor input scales must be unswizzled for grouped GEMM"
    )
    assert input_act.qdata.ndim == 2, "MXTensor input_act data must be 2D"
    assert input_act.scale.ndim == 2, "MXTensor input_act scale must be 2D"
    assert input_act.scale.shape == (
        input_act.shape[0],
        input_act.shape[1] // block_size,
    ), (
        "MXTensor input scales must be rowwise with shape "
        f"({input_act.shape[0]}, {input_act.shape[1] // block_size})"
    )
