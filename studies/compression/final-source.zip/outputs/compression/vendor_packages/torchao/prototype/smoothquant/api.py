# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD 3-Clause license found in the
# LICENSE file in the root directory of this source tree.
import types
from dataclasses import dataclass
from typing import Optional

import torch

from torchao.core.config import AOBaseConfig
from torchao.quantization.quant_api import (
    _QUANTIZE_CONFIG_HANDLER,
    _linear_extra_repr,
)
from torchao.quantization.quantize_.common import (
    IsStaticQuantizationConfig,
    SupportsActivationPreScaling,
)
from torchao.quantization.quantize_.common.quantization_step import QuantizationStep
from torchao.quantization.transform_module import (
    register_quantize_module_handler,
)
from torchao.utils import DummyModule

from .core import (
    RunningAbsMaxSmoothQuantObserver,
    SmoothQuantObservedLinear,
    SmoothQuantObserver,
)


@dataclass
class SmoothQuantConfig(AOBaseConfig):
    """
    Configuration for SmoothQuant quantization when passed into quantize_()

    Args:
        base_config: Base quantization configuration that SmoothQuant is applied on top of
        step (QuantizationStep): The step for SmoothQuant process
            PREPARE: insert SmoothQuant Observers to linear layers
            CONVERT: convert the observed linear modules to quantized modules
            PREPARE_FOR_LOADING: convert the floating point model to a dummy smoothquant quantized model, so we can
            load the quantized weights through copy_ later
            PREPARE_FOR_SMOOTHQUANT_SMOOTHING_FACTOR: compute smoothing factor after first calibration pass
                (for RunningAbsMaxSmoothQuantObserver two-pass calibration)
            PREPARE_FOR_SMOOTHQUANT_ACTIVATION_SCALES: reserved for future use
        alpha: The alpha value to determine smoothing factor. Factor = 1 if alpha is None, which means
            Fall back to conventional quantization if None
        use_running_absmax: If True, use RunningAbsMaxSmoothQuantObserver for memory-efficient calibration
    """

    base_config: AOBaseConfig
    step: QuantizationStep
    alpha: Optional[float] = 0.5
    use_running_absmax: bool = False

    def __post_init__(self):
        self.step = self.step.lower() if isinstance(self.step, str) else self.step.value
        all_step_values = [s.value for s in QuantizationStep]
        if self.step not in all_step_values:
            raise ValueError(f"{self.step} is not one of {all_step_values}")


@register_quantize_module_handler(SmoothQuantConfig)
def _smooth_quant_transform(
    module: torch.nn.Module,
    config: SmoothQuantConfig,
) -> torch.nn.Module:
    step = config.step
    base_config = config.base_config

    observer_cls = (
        RunningAbsMaxSmoothQuantObserver
        if config.use_running_absmax
        else SmoothQuantObserver
    )

    if step == QuantizationStep.PREPARE:
        observer = observer_cls(
            weight=module.weight,
            alpha=config.alpha,
        )
        return SmoothQuantObservedLinear.from_float(module, observer)

    if step == QuantizationStep.PREPARE_FOR_LOADING:
        # loading from pre-quantized checkpoint
        observer = observer_cls(
            weight=module.weight,
            alpha=config.alpha,
        )
        observed_linear = SmoothQuantObservedLinear.from_float(module, observer)
        example_input = torch.randn(
            (1, module.weight.shape[1]),
            device=module.weight.device,
            dtype=module.weight.dtype,
        )
        observed_linear(example_input)

    elif step == QuantizationStep.CONVERT:
        if not isinstance(module, SmoothQuantObservedLinear):
            print(
                f"convert: module is not SmoothQuantObservedLinear, skipping: {type(module)}"
            )
            return module
        observed_linear = module

    elif step == QuantizationStep.PREPARE_FOR_SMOOTHQUANT_SMOOTHING_FACTOR:
        if not isinstance(module, SmoothQuantObservedLinear):
            return module
        obs = module.obs
        if isinstance(obs, RunningAbsMaxSmoothQuantObserver):
            obs.compute_smoothing_factor()
        return module

    elif step == QuantizationStep.PREPARE_FOR_SMOOTHQUANT_ACTIVATION_SCALES:
        # Reserved for future use
        return module
    else:
        raise ValueError(f"Unexpected step: {step}")

    quant_kwargs = (
        base_config.get_act_quant_kwargs()
        if isinstance(base_config, IsStaticQuantizationConfig)
        else None
    )

    # Compute smoothed weight parameters
    smoothing_factor, activation_scale, activation_zero_point = (
        observed_linear.obs.calculate_qparams(weight_quant_kwargs=quant_kwargs)
    )
    weight = observed_linear.weight * smoothing_factor

    # Create new linear layer
    with torch.device("meta"):
        linear = torch.nn.Linear(
            observed_linear.in_features,
            observed_linear.out_features,
            observed_linear.bias is not None,
            device=observed_linear.weight.device,
            dtype=observed_linear.weight.dtype,
        )
    linear.bias = observed_linear.bias

    # Quantize weights
    if isinstance(base_config, IsStaticQuantizationConfig):
        base_config.act_quant_scale = activation_scale
        base_config.act_quant_zero_point = activation_zero_point

    base_config_handler = _QUANTIZE_CONFIG_HANDLER[type(base_config)]
    dummy_mod = DummyModule(weight)
    quant_mod = base_config_handler(dummy_mod, base_config)
    qw = quant_mod.weight

    # Add smoothing factor as activation pre-scale
    assert isinstance(qw, SupportsActivationPreScaling), (
        "weight must support activation scaling through implementing `SupportsActivationPreScaling`"
    )
    # Store reciprocal for runtime efficiency: act * act_pre_scale
    qw.act_pre_scale = 1.0 / smoothing_factor

    linear.weight = torch.nn.Parameter(qw, requires_grad=False)
    linear.extra_repr = types.MethodType(_linear_extra_repr, linear)

    return linear
