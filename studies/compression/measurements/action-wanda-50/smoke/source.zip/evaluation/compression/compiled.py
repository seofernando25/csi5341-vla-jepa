"""Scoped Linear compilation controls for TorchAO's intended deployment path.

Compile the functional operation, preserving module paths, hooks and tensor
payloads. This is a Linear-only backend comparison, not whole-policy fusion.
"""

from functools import partial
from types import MethodType

import torch
from torch.nn import functional as F

from evaluation.compression.transforms import selected_linears


def linear_operation(inputs, weight, bias):
    return F.linear(inputs, weight, bias)


def compiled_forward(operation, module, inputs):
    return operation(inputs, module.weight, module.bias)


def compile_linears(policy, change):
    entries = selected_linears(policy, change["scope"])
    if not entries:
        raise ValueError("No Linear modules found for compilation")
    if any(hasattr(linear, "_compression_compile_options") for _, _, linear in entries.values()):
        raise ValueError("Linear compilation already applied in this scope")
    # One shared functional graph handles multiple projection widths and input
    # layouts. Exceeding this recorded limit fails instead of using eager code.
    torch._dynamo.config.recompile_limit = 128
    torch._dynamo.config.suppress_errors = False
    options = {"backend": "inductor", "mode": "default", "fullgraph": True, "dynamic": True}
    operation = torch.compile(linear_operation, **options)
    for _, _, linear in entries.values():
        linear.forward = MethodType(partial(compiled_forward, operation), linear)
        linear._compression_compile_options = options.copy()
    return {
        "method": "compile_linears",
        "scope": change["scope"],
        "options": options,
        "recompile_limit": 128,
        "silent_eager_fallback": False,
        "compiled_modules": list(entries),
        "interpretation": "Scoped Linear compilation; remaining policy operations are eager",
    }
